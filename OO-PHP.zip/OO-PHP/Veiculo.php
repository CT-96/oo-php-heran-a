<?php

class Veiculo
{
	public $color;
	public $brand;
	public $enginer;
}