<?php

require 'Car.php';
//require 'Motocicleta.php';

$ferrari = new Car;
$ferrari->brand = "ferrari";
$ferrari->color = "yellon";
$ferrari->enginer = 300;

/*$dafra = new Motocicleta;
$dafra->brand = "dafra";
$dafra->color = "blue";
$dafra->enginer = 150;*/

//var_dump($dafra);
echo "<br>";
var_dump($ferrari);