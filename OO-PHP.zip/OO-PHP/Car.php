<?php

require 'Veiculo.php';
class Car extends Veiculo
{

}