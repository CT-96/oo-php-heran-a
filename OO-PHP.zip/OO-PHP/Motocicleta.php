<?php
/*
require 'Veiculo.php';
class Motocicleta extends Veiculo
{
	
}